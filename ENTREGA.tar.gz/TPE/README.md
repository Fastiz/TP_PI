# TRABAJO PRACTICO PI

1) Compilar:

    gcc programaCenso.c censoTAD.c -o programaCenso-Wall -pedantic -std=c99

2) Correr el programa:

    ./programaCenso (ingresar linea por linea) o ./programaCenso < censo.csv (para leer desde un archivo).
